// Array met tafels
var tafels = [2, 4, 6, 8];

// Referentie naar output element
var output = document.getElementById('output');

// Loop door elke tafel in de array
for (let i = 0; i < tafels.length; i++) {
    let getal = tafels[i];
    
    // Schrijf de header voor deze tafel
    output.innerHTML += '<h2>Tafel van ' + getal + '</h2>';
    
    // Bereken en toon de tafel van 1 tot en met 10
    for (let j = 1; j <= 10; j++) {
        let resultaat = j * getal;
        output.innerHTML += j + ' x ' + getal + ' = ' + resultaat + '<br>';
    }
    
    // Extra witruimte tussen tafels
    output.innerHTML += '<br>';
}
C++
C