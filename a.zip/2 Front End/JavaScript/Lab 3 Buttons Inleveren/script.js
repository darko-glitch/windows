// Stel de body styling in
document.body.style.margin = '0';
document.body.style.padding = '0';
document.body.style.height = '100vh';
document.body.style.display = 'flex';
document.body.style.justifyContent = 'center';
document.body.style.alignItems = 'center';
document.body.style.backgroundColor = 'grey';

// Krijg referentie naar container
let container = document.getElementById('container');

// Style de container (wit panel)
container.style.backgroundColor = 'white';
container.style.padding = '20px';
container.style.borderRadius = '5px';
container.style.display = 'flex';
container.style.gap = '10px';

// Maak button 1 (groen)
let button1 = document.createElement('button');
button1.textContent = 'Button 1';
button1.style.backgroundColor = 'green';
button1.style.color = 'white';
button1.style.border = 'none';
button1.style.padding = '10px 20px';
button1.style.cursor = 'pointer';
button1.style.fontSize = '16px';
button1.onclick = function() {
    document.body.style.backgroundColor = 'green';
};

// Maak button 2 (rood)
let button2 = document.createElement('button');
button2.textContent = 'Button 2';
button2.style.backgroundColor = 'red';
button2.style.color = 'white';
button2.style.border = 'none';
button2.style.padding = '10px 20px';
button2.style.cursor = 'pointer';
button2.style.fontSize = '16px';
button2.onclick = function() {
    document.body.style.backgroundColor = 'red';
};

// Maak button 3 (blauw)
let button3 = document.createElement('button');
button3.textContent = 'Button 3';
button3.style.backgroundColor = 'blue';
button3.style.color = 'white';
button3.style.border = 'none';
button3.style.padding = '10px 20px';
button3.style.cursor = 'pointer';
button3.style.fontSize = '16px';
button3.onclick = function() {
    document.body.style.backgroundColor = 'blue';
};

// Voeg buttons toe aan container
container.appendChild(button1);
container.appendChild(button2);
container.appendChild(button3);
