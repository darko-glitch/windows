const t1 = 0;
const t2 = 1;

const n = prompt("Enter the number of terms: ");
let n1 = t1, n2 = t2, nextTerm;
let result = "";

for (let i = 1; i <= n; i++) {
  result += n1 + " ";
  nextTerm = n1 + n2;
  n1 = n2;
  n2 = nextTerm;
}

document.body.innerHTML = "<h2>Fibonacci Sequence:</h2><p>" + result + "</p>";
