// Vraag het aantal namen op
let aantal = parseInt(prompt('Hoeveel namen wilt u in de array stoppen? (minimaal 3)'));

// Validatie: zorg dat het minimaal 3 is
while (aantal < 3 || isNaN(aantal)) {
    aantal = parseInt(prompt('U moet minimaal 3 namen invoeren. Probeer opnieuw:'));
}

// Array om namen op te slaan
let namen = [];

// Vraag de namen op
for (let i = 0; i < aantal; i++) {
    let naam = prompt(`Voer naam ${i + 1} in:`);
    namen.push(naam);
}

// Maak de output
let output = document.getElementById('output');

// Toon de originele namen
output.innerHTML += '<h2>De ingevoerde namen in de array zijn:</h2>';
for (let i = 0; i < namen.length; i++) {
    output.innerHTML += namen[i] + '<br>';
}

// Toon de namen in omgekeerde volgorde
output.innerHTML += '<h2>De ingevoerde namen in de array in omgekeerde volgorde zijn:</h2>';
for (let i = namen.length - 1; i >= 0; i--) {
    output.innerHTML += namen[i] + '<br>';
}