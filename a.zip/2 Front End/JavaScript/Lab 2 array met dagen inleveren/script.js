// Array met dagen van de week
const dagenVanDeWeek = ["maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag", "zondag"];

// Alle dagen van de week zijn
document.getElementById("alleDagen").textContent = dagenVanDeWeek.join(", ");

// De werkdagen zijn
const werkdagen = dagenVanDeWeek.slice(0, 5);
document.getElementById("werkdagen").textContent = werkdagen.join(", ");

// De weekenddagen zijn
const weekenddagen = dagenVanDeWeek.slice(5, 7);
document.getElementById("weekenddagen").textContent = weekenddagen.join(", ");

// Alle dagen van de week in omgekeerde volgorde zijn
const alleDagenOmgekeerd = [...dagenVanDeWeek].reverse();
document.getElementById("alleDagenOmgekeerd").textContent = alleDagenOmgekeerd.join(", ");

// De werkdagen in omgekeerde volgorde zijn:
const werkdagenOmgekeerd = [...werkdagen].reverse();
document.getElementById("werkdagenOmgekeerd").textContent = werkdagenOmgekeerd.join(", ");

// De weekenddagen in omgekeerde volgorde zijn:
const weekenddagenOmgekeerd = [...weekenddagen].reverse();
document.getElementById("weekenddagenOmgekeerd").textContent = weekenddagenOmgekeerd.join(", ");