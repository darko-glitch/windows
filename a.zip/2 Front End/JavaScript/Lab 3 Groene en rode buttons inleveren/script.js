// Aantal buttons dat je wilt maken (variabel)
let aantalButtons = 30;

// Stel body styling in
document.body.style.margin = '0';
document.body.style.padding = '20px';
document.body.style.backgroundColor = '#f0f0f0';

// Krijg referentie naar container
let container = document.getElementById('container');

// Style de container
container.style.display = 'grid';
container.style.gridTemplateColumns = 'repeat(5, 1fr)';
container.style.gap = '10px';
container.style.maxWidth = '600px';
container.style.margin = '0 auto';
container.style.padding = '20px';
container.style.backgroundColor = 'grey';

// Maak buttons aan
for (let i = 1; i <= aantalButtons; i++) {
    let button = document.createElement('button');
    button.textContent = i;
    button.style.backgroundColor = 'green';
    button.style.color = 'black';
    button.style.border = '2px solid black';
    button.style.padding = '20px';
    button.style.fontSize = '20px';
    button.style.fontWeight = 'bold';
    button.style.cursor = 'pointer';
    button.style.minHeight = '60px';
    
    // Voeg click event toe
    button.onclick = function() {
        if (this.style.backgroundColor === 'green') {
            this.style.backgroundColor = 'red';
        }
    };
    
    // Voeg button toe aan container
    container.appendChild(button);
}
