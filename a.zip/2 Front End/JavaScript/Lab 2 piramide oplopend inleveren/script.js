// Vraag om een getal
let getal = parseInt(prompt('Voer een getal in:'));

// Validatie
while (isNaN(getal) || getal < 1) {
    getal = parseInt(prompt('Voer een geldig getal in:'));
}

// Maak een array aan van 0 tot en met het ingevoerde getal
let array = [];
for (let i = 0; i <= getal; i++) {
    array.push(i);
}

// Referentie naar output element
let output = document.getElementById('output');

// Toon de array
output.innerHTML += 'Array : ' + array.join(',') + '<br><br>';

// Bouw de pyramide op
for (let i = 0; i <= getal; i++) {
    let regel = '';
    for (let j = 0; j <= i; j++) {
        regel += array[j];
    }
    output.innerHTML += regel + '<br>';
}