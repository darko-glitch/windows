// Arrays aanmaken
var arrayEen = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var arrayTwee = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20];

// Referentie naar output element
var output = document.getElementById('output');

// Functie voor optellen
function optellen(arr1, arr2) {
    for (let i = 0; i < arr1.length; i++) {
        let resultaat = arr1[i] + arr2[i];
        output.innerHTML += arr1[i] + ' + ' + arr2[i] + ' = ' + resultaat + '<br>';
    }
    output.innerHTML += '<br>';
}

// Functie voor aftrekken
function aftrekken(arr1, arr2) {
    for (let i = 0; i < arr1.length; i++) {
        let resultaat = arr1[i] - arr2[i];
        output.innerHTML += arr1[i] + ' - ' + arr2[i] + ' = ' + resultaat + '<br>';
    }
    output.innerHTML += '<br>';
}

// Functie voor vermenigvuldigen
function vermenigvuldigen(arr1, arr2) {
    for (let i = 0; i < arr1.length; i++) {
        let resultaat = arr1[i] * arr2[i];
        output.innerHTML += arr1[i] + ' * ' + arr2[i] + ' = ' + resultaat + '<br>';
    }
    output.innerHTML += '<br>';
}

// Functie voor delen
function delen(arr1, arr2) {
    for (let i = 0; i < arr1.length; i++) {
        let resultaat = arr1[i] / arr2[i];
        output.innerHTML += arr1[i] + ' / ' + arr2[i] + ' = ' + resultaat + '<br>';
    }
    output.innerHTML += '<br>';
}

// Functies aanroepen
optellen(arrayEen, arrayTwee);
aftrekken(arrayTwee, arrayEen);
vermenigvuldigen(arrayEen, arrayTwee);
delen(arrayTwee, arrayEen);